part of 'medical_history_bloc.dart';

@immutable
sealed class MedicalHistoryEvent {}
class GetMedicalHistoryEvent extends MedicalHistoryEvent {

}