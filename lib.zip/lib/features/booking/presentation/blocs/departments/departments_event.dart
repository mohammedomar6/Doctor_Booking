part of 'departments_bloc.dart';

class DepartmentsEvent {}

class GetAllDepartmentsBooking extends DepartmentsEvent {}
