import 'package:flutter/material.dart';

class MyColours{
  static Color white= Color(0xffffffff);
  static Color blue = Color(0xff0165fc);
  static Color red = Color(0xffda0d0d);
  static Color black = Color(0xff000000);
  static Color grey = Color(0xffC0C0C0);
  static Color star = Color(0xFFFFC107);
  static Color lightBlack =  Color(0xFF0A0E21);
}
