class MyImages{
  static String loginImage= 'assets/images/login_image.jpg';
  static String signUpImage= 'assets/images/sign_up_image.jpg';
  static String  forgotPassword= 'assets/images/forgotpassword.jpg';
  static String  resetPassword= 'assets/images/forgotpassword.jpg';
  static String  introImage1= 'assets/images/p1.jpg';
  static String  introImage2= 'assets/images/p2.jpg';
  static String  introImage3= 'assets/images/p3.jpg';

  // home
  static String doc1 = "assets/images/doc1.jpg";
  static String doc2 = "assets/images/doc2.jpg";
  static String doc3 = "assets/images/doc3.jpg";
  static String doc4 = "assets/images/doc4.jpg";
  static String doc5 = "assets/images/doc5.jpg";
  static String question = "assets/images/question.jpg";
}